package com.twilio.http.bearertoken;

public interface TokenManager {
    String fetchAccessToken();
}